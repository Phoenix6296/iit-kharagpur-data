README

Task Overview

This assignment consists of one tasks, represented by a  C++ source file named as 24CS60R71_A11_T.c. The following are the execution commands for compiling and running the task.

Compile and Execute

To compile and execute the task, use the following commands:

gcc -o chaos_order 24CS60R71_A11_T.c -lpthread
./chaos_order

Prerequisites

Make sure that the GCC compilers are installed and configured properly. The assignment uses C++20 standard so ensure that your compiler supports it.